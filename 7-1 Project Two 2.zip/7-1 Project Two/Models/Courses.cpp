#include "Courses.h"
#include <iostream>
#include <algorithm> // for std::sort

Courses::Courses() {}

void Courses::Insert(const Course& course) {
    // Insert course into hash table
    coursesHashTable[course.getCourseId()] = course;
}

void Courses::Remove(const std::string& courseId) {
    // Remove course from hash table
    auto it = coursesHashTable.find(courseId);
    if (it != coursesHashTable.end()) {
        coursesHashTable.erase(it);
    }
}

void Courses::PrintCourseList() const {
    std::vector<std::string> sortedCourseIds;
    for (const auto& entry : coursesHashTable) {
        sortedCourseIds.push_back(entry.first);
    }

    std::sort(sortedCourseIds.begin(), sortedCourseIds.end());

    std::cout << "Course List:" << std::endl;
    for (const auto& courseId : sortedCourseIds) {
        std::cout << coursesHashTable.at(courseId).courseToString() << std::endl;
    }
}

void Courses::PrintCourse(const std::string& courseNumber) const {
    auto it = coursesHashTable.find(courseNumber);
    if (it != coursesHashTable.end()) {
        const Course& course = it->second;
        std::cout << "Course Information:" << std::endl;
        std::cout << "Course ID: " << course.getCourseId() << std::endl;
        std::cout << "Course Name: " << course.getCourseName() << std::endl;
        const auto& prerequisites = course.getCoursePrerequisites();
        if (!prerequisites.empty()) {
            std::cout << "Prerequisites: ";
            for (size_t i = 0; i < prerequisites.size() - 1; ++i) {
                std::cout << prerequisites[i] << ", ";
            }
            std::cout << prerequisites.back();
        }
        else {
            std::cout << "No Prerequisites";
        }
        std::cout << std::endl;
    }
    else {
        std::cout << "Course not found." << std::endl;
    }
}
