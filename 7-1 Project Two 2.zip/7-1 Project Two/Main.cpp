#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include "Courses.h"

void loadCourses(const std::string& inputFilePath, Courses& coursesBst) {
    std::ifstream file(inputFilePath);
    if (!file.is_open()) {
        std::cerr << "Error opening file: " << inputFilePath << std::endl;
        return;
    }

    std::string currentLine;
    while (std::getline(file, currentLine)) {
        std::stringstream ss(currentLine);
        std::string number, title;
        std::vector<std::string> prerequisites;

        std::getline(ss, number, ',');
        std::getline(ss, title, ',');

        std::string prereq;
        while (std::getline(ss, prereq, ',')) {
            prerequisites.push_back(prereq);
        }

        Course course(number, title, prerequisites);
        coursesBst.Insert(course);
    }

    file.close();
}

int main() {
    Courses coursesBst;
    std::string inputPath;

    std::cout << "Welcome to the course planner." << std::endl << std::endl;

    int choice = 0;
    while (choice != 4) {
        std::cout << "1. Load Data Structure" << std::endl;
        std::cout << "2. Print Course List" << std::endl;
        std::cout << "3. Print Course" << std::endl;
        std::cout << "4. Exit Application" << std::endl << std::endl;
        std::cout << "What would you like to do? ";
        std::cin >> choice;

        switch (choice) {
        case 1:
            std::cout << "Enter the path to the input file: ";
            std::cin >> inputPath;
            loadCourses(inputPath, coursesBst);
            break;
        case 2:
            std::cout << "Here is a sample schedule:" << std::endl << std::endl;
            coursesBst.PrintCourseList();
            break;
        case 3:
            std::cout << "Enter the course number: ";
            std::string courseNumber;
            std::cin >> courseNumber;
            coursesBst.PrintCourse(courseNumber);
            break;
        case 4:
            std::cout << "Goodbye." << std::endl;
            break;
        default:
            std::cout << "Invalid option. Please try again." << std::endl;
            break;
        }

        std::cout << std::endl;
    }

    return 0;
}